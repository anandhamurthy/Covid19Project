package com.covid19project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    GridView grid;
    String[] web = {
            "Home Treatment",
            "My Health Status",
            "Medical stores",
            "Volunteers Registration",
            "Hospital Admissions ",
            "Labs for Test",
            "Vocational Training Courses",
            "Counselling",
            "E-Pass",
            "Donate Funds",
            "Support",
            "Doctor’s Appointment"

    } ;
    int[] imageId = {
            R.drawable.home,
            R.drawable.health,
            R.drawable.medical_store,
            R.drawable.volunteer,
            R.drawable.hospital,
            R.drawable.lab,
            R.drawable.training,
            R.drawable.counselling,
            R.drawable.pass,
            R.drawable.donate,
            R.drawable.support,
            R.drawable.doctor

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GridAdapter adapter = new GridAdapter(MainActivity.this, web, imageId);
        grid=findViewById(R.id.grid_view);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(MainActivity.this, "You Clicked at " +web[+ position], Toast.LENGTH_SHORT).show();

            }
        });

    }
}
